#pragma once
class Ngc3
{

};


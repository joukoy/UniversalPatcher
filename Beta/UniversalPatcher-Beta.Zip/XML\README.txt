UniversalPatcher XML folder
===========================

Platforms\<family>\   Segment configs (xxx.xml), platform configs (xxx-platform.xml),
                      TableSeek-xxx.xml and SegmentSeek-xxx.xml for one ECU/TCM/BCM family.
Common\               Shared databases: autodetect, OBD2 codes, PID lists, DTC/PID search, CAN modules...
Reference\            CVN reference data (stockcvn.xml, Reference-CVN.xml, addresses-*.xml)
TunerColumns\         Tuner column presets (Columns-Tourist/Basic/Advanced.xml)

Files are found BY NAME, from any subfolder (case-insensitive).
You can still drop your own files directly into this XML folder; they work as before.
If the same file name exists both here (root) and in a subfolder, the subfolder copy is used
and UniversalPatcher offers to move the old root copy to XML\_obsolete.
New platform/TableSeek/SegmentSeek files are created next to their segment config.

﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Xml.Serialization;

namespace UniversalPatcher
{
    public class UpatcherSettings
    {
        public UpatcherSettings()
        {
            OpenInStartup = StartupUtil.Launcher;
            SuppressAfter = 10;
            AutorefreshCVNlist = true;
            AutorefreshFileinfo = true;
            MainWindowPersistence = true;
            TableEditorAutoResize = true;
            TunerMinTableEquivalency = 100;
            TableEditorMinTableEquivalency = 100;
            keyPressWait100ms = 2;
            TableEditorMinOtherEquivalency = 100;
            MassCopyTableFilenameExtra = "-new";
            TableExplorerIconSize = 16;
            TunerTreeMode = true;
            TunerAutomulti1d = true;
            MultitableChars = ". [ ]";
            WorkingMode = 0;
            RequireValidVerForStock = true;
            TunerShowUnitsUndefined = true;
            TunerShowUnitsImperial = true;
            TunerShowUnitsMetric = true;
            TunerPreviewTablesMax = 10;
            TunerColorsMode = Upatcher.ConditionalColors.Values;
            TunerColorsMin = System.Drawing.ColorTranslator.ToHtml(Color.FromArgb(71, 206, 71));// lime green  (min)
            TunerColorsMid1 = System.Drawing.ColorTranslator.ToHtml(Color.FromArgb(255, 255, 26));// yellow
            TunerColorsMid2 = System.Drawing.ColorTranslator.ToHtml(Color.FromArgb(255, 143, 26));// orange
            TunerColorsMax = System.Drawing.ColorTranslator.ToHtml(Color.FromArgb(255, 160, 160));// deep red    (max)

            SplashShowTime = 4;
            FlashApp = "PCMHammer\\pcmhammer.exe";
            FLashParams = "--writecalibration $file";
            LoggerUseIntegrated = true;
            LoggerResponseMode = "SendOnce";
            LoggerBaudRate = 115200;
            LoggerScriptDelay = 10;
            JConsole4x = true;
            LoggerConsole4x = true;
            LoggerGraphicsInterval = 1;
            LoggerGraphicsShowMaxTime = 10;
            LoggerGrapohicsBackColor = System.Drawing.ColorTranslator.ToHtml(Color.White);
            LoggerGraphicsLogLastProfileFile = "profile1.xml";
            LoggerGraphicsLiveLastProfileFile = "live1.xml";
            LoggerGraphicsLineWidth = 1;
            LoggerGraphicsColorPalette = System.Windows.Forms.DataVisualization.Charting.ChartColorPalette.BrightPastel;
            LoggerTimestampFormat = "HH:mm:ss.ffff";
            LoggerLogSeparator = ",";
            LoggerDecimalSeparator = ".";
            LoggerLastFilterOS = "";
            TunerShowTableCount = true;
            TunerHexWindowShow = false;
            TunerHexWindowColumns = 16;
            TunerHexWindowWidth = 300;
            TunerHexWindowHighlightBackground = false;
            TunerHexWindowHeaders = false;
            TunerHexWindowOffsets = false;
            TunerHexWindowAscii = false;
            TunerHexWindowBackColor = System.Drawing.ColorTranslator.ToHtml(Color.Black);
            TunerHexWindowDataColor = "#056017";
            TunerHexWindowOtherDataColor = System.Drawing.ColorTranslator.ToHtml(Color.LightBlue);
            TunerHexWindowSelectionColor = System.Drawing.ColorTranslator.ToHtml(Color.Red);
            TunerHexWindowModifiedColor = System.Drawing.ColorTranslator.ToHtml(Color.Yellow);
            TunerTreeUseMouseHover = true;
            TableCellMouseHover = false;
            TunerXYSwapWideTables = false;
            //TunerModeColumns = "TableName,Category,Units,Columns,Rows,TableDescription";
            //ConfigModeColumnWidth = "180,114,32,63,86,71,48,81,100,50,78,49,69,60,54,43,58,64,43,78,100,100,243,100,100";
            //TunerModeColumnWidth = "192,110,100,100,100,100,100,100,100,72,100,100,100,100,60,46,100,100,100,100,100,100,197,100,100";
            NavigatorMaxTablesPerNode = 3;
            NavigatorMaxTablesTotal = 50;
            LoggerStartJ2534Process = true;
            LoggerJ2534ProcessVisible = false;
            LoggerStartJ2534ProcessDebug = false;
            LoggerJ2534ProcessWriteDebugLog = false;
            LoggerAutoDisconnect = true;
            LoggerFilterStartOfMessage = true;
            LoggerFilterTXIndication = true;
            LoggerFilterRxStatusCustom = "";
            //LoggerUseVPW = true;
            LoggerConsoleDisplayInterval = 200;
            LoggerTesterPresentInterval = 4000;
            LoggerCanPcmAddress = 0x07E0;
            LoggerTestPidCompatibility = true;
            LoggerRetryAfterSeconds = 2;
            LoggerRetryCount = 3;
            LoggerCANWaitSecondsStopMessages = 5;
            LoggerStartKey = Keys.F4;
            LoggerPidMismatchRemember = false;
            LoggerDeviceUrl = "192.168.4.1:22222";
            LoggerPortType = DataLogger.iPortType.Serial;
            loggerProtocol = DataLogger.LoggingProtocol.VPW;
            SerialServerPort = 22222;
            SerialServerBaudRate = 115200;

            RetryWriteTimes = 3;
            RetryWriteDelay = 10;
            ClearFuncAddrOnDisconnect = true;
            LoggerGraphDisableResample = false;
            TableEditorHexShowAddress = false;
            TableEditorHexShowBinary = false;
            TableEditorHexShowDecimal = false;
            ConfirmProgramExit = true;
            TunerUseSessionTabs = false;
            HistogramLastLiveProfiles = new List<string>();
            HistogramLastLogfileProfiles = new List<string>();
            LastScriptFile = "";
            LastJScriptFile = "";
            DashboardRows = 2;
            DashboardCols = 3;
            AnalyzerNumMessages = 1;
            LoggerLoggingMessagesPerRequest = 1;
            LoggerRestartAfterSeconds = 30;
            WBCanID = "7E6";
            WBCanBaudrate = 115200;
            WBDebug = false;
            WBCanBytePosition = 2;
            WBCanByteCount = 1;
            WBCanAfrFactor = 0.01;

            TimeoutLoggingActive = TimeoutScenario.DataLogging3;
            TimeoutLoggingActiveObdlink = TimeoutScenario.Minimum;
            TimeoutLoggingPassive = TimeoutScenario.DataLogging4;
            TimeoutReceive = 100;
            TimeoutReceivePerMessage = 30;
            TimeoutLoggingReceive = 100;
            TimeoutScriptRead = 100;
            //TimeoutScriptWrite = 100;
            TimeoutJ2534Write = 30;
            TimeoutSerialPortRead = 2000;
            TimeoutSerialPortWrite = 100;
            TimeoutAvtRead = 3000;
            TimeoutAnalyzerReceive = 3000;
            TimeoutConsoleReceive = 100;
            TimeoutJConsoleReceive = 100;
            //TimeoutLoggingWrite = 100;
            //TimeoutJLoggingWrite = 0;
            //TimeoutJconsoleWrite = 100;
            //TimeoutJ2534DeviceRead = 20;

            TableEditorFont = new SerializableFont(new Font("Consolas", 8));
            TableExplorerFont = new SerializableFont(new Font("Arial", 8));
            PatcherLogFont = new SerializableFont(new Font("Consolas", 8));
            DebugFont = new SerializableFont(new Font("Consolas", 8));
            LoggerConsoleFont = new SerializableFont(new Font("Consolas", 8));
            TunerHexWindowFont = new SerializableFont(new Font("Consolas", 8));
        }
        public enum StartupUtil
        {
            Launcher,
            Tuner,
            Logger,
            Patcher
        }

        public StartupUtil OpenInStartup { get; set; }
        //public string LastXMLfolder { get; set; }
        //public string LastPATCHfolder { get; set; }
        //public string LastBINfolder { get; set; }
        public uint SuppressAfter { get; set; }
        public bool DebugOn { get; set; }
        public bool AutorefreshCVNlist { get; set; }
        public bool AutorefreshFileinfo { get; set; }
        public bool MainWindowPersistence { get; set; }
        public Size MainWindowSize { get; set; }
        public FormWindowState MainWindowState { get; set; }
        public Point MainWindowLocation { get; set; }
        public Size EditXMLWindowSize { get; set; }
        public FormWindowState EditXMLWindowState { get; set; }
        public Point EditXMLWindowLocation { get; set; }
        public Size FileSelectionWindowSize { get; set; }
        public FormWindowState FileSelectionWindowState { get; set; }
        public Point FileSelectionWindowLocation { get; set; }
        public Size TableEditorWindowSize { get; set; }
        public FormWindowState TableEditorWindowState { get; set; }
        public Point TableEditorWindowLocation { get; set; }
        public bool TableEditorAutoResize { get; set; }
        public Size TunerWindowSize { get; set; }
        public FormWindowState TunerWindowState { get; set; }
        public Point TunerWindowLocation { get; set; }
        public Size TunerMainWindowSize { get; set; }
        public FormWindowState TunerMainWindowState { get; set; }
        public Point TunerMainWindowLocation { get; set; }
        public Size frmGraphicsWindowSize { get; set; }
        public FormWindowState frmGraphicsWindowState { get; set; }
        public Point frmGraphicsWindowLocation { get; set; }
        public bool disableTunerAutoloadSettings { get; set; }
        //public string TunerModeColumns { get; set; }
        //public string ConfigModeColumnOrder { get; set; }
        //public string ConfigModeColumnWidth { get; set; }
        //public string TunerModeColumnWidth { get; set; }
        public Size TunerLogWindowSize { get; set; }
        public int PatcherSplitterDistance { get; set; }
        //public Font TableEditorFont { get; set; }
        public Size frmTdWindowSize { get; set; }
        public FormWindowState frmTdWindowState { get; set; }
        public Point frmTdWindowLocaction { get; set; }
        public Size MassCompareWindowSize { get; set; }
        public FormWindowState MassCompareWindowState { get; set; }
        public Point MassCompareWindowLocation { get; set; }
        public int MassCompareSplitWidth { get; set; }
        public Size MassModifyTableDataWindowSize { get; set; }
        public FormWindowState MassModifyTableDataWindowState { get; set; }
        public Point MassModifyTableDataWindowLocation { get; set; }
        public int MassModifyTableDataWindowSplitterDistance { get; set; }
        public int TunerMinTableEquivalency { get; set; }
        public int TableEditorMinTableEquivalency { get; set; }
        public int keyPressWait100ms { get; set; }
        public int TableEditorMinOtherEquivalency { get; set; }
        public bool TableEditorHexShowAddress { get; set; }
        public bool TableEditorHexShowBinary { get; set; }
        public bool TableEditorHexShowDecimal { get; set; }
        public Point MassCopyTableWindowLocation { get; set; }
        public FormWindowState MassCopyTableWindowState { get; set; }
        public Size MassCopyTableWindowSize { get; set; }
        public int MassCopyTableSplitHeight { get; set; }
        public string MassCopyTableFilenameExtra { get; set; }
        //public Font TableExplorerFont { get; set; }
        public int TableExplorerIconSize { get; set; }
        public Size TableExplorerWindowSize { get; set; }
        public FormWindowState TableExplorerWindowState { get; set; }
        public Point TableExplorerWindowPosition { get; set; }
        public bool TableExplorerUseCategorySubfolder { get; set; }
        public Point TunerExplorerWindowLocation { get; set; }
        public FormWindowState TunerExplorerWindowState { get; set; }
        public Size TunerExplorerWindowSize { get; set; }
        public int TunerExplorerWindowSplitterDistance { get; set; }
        public int TunerExplorerWindowSplitter2Distance { get; set; }
        public bool TunerTreeMode { get; set; }
        public bool TunerAutomulti1d { get; set; }
        public int TunerListModeTreeWidth { get; set; }
        public string MultitableChars { get; set; }
        public bool DisableAutoFixChecksum { get; set; }
        public int WorkingMode { get; set; }
        public bool CvnPopupAccepted { get; set; }
        public bool RequireValidVerForStock { get; set; }
        public bool AutomaticOpenImportedFile { get; set; }
        public bool TunerShowUnitsUndefined { get; set; }
        public bool TunerShowUnitsImperial { get; set; }
        public bool TunerShowUnitsMetric { get; set; }
        public bool TunerUseSessionTabs { get; set; }
        public bool TunerXYSwapWideTables { get; set; }
        public int TunerPreviewTablesMax { get; set; }
        public int SplashShowTime { get; set; }
        //public Font PatcherLogFont { get; set; }
        //public Font DebugFont { get; set; }
        public bool xdfImportUseTableName { get; set; }
        public string FlashApp { get; set; }
        public string FLashParams { get; set; }
        public bool LoggerUseIntegrated { get; set; }
        public string LoggerExternalApp { get; set; }
        public string LoggerComPort { get; set; }
        public string LoggerLastProfile { get; set; }
        public string LoggerLogFolder { get; set; }
        public string LoggerJ2534Device { get; set; }
        public bool LoggerPassive { get; set; }
        public bool LoggerUseJ2534 { get; set; }
        public string LoggerSerialDeviceType { get; set; }
        public string LoggerResponseMode { get; set; }
        public DataLogger.iPortType LoggerPortType { get; set; }
        public bool LoggerShowAdvanced { get; set; }
        public string LoggerFTDIPort { get; set; }
        public string LoggerDeviceUrl { get; set; }

        public int LoggerBaudRate { get; set; }
        public bool LoggerUseFilters { get; set; }
        //public bool LoggerUseVPW { get; set; }
        public DataLogger.LoggingProtocol loggerProtocol { get; set; }
        public bool LoggerStartPeriodic { get; set; }
        public bool LoggerWakeUp { get; set; }
        public Size LoggerWindowSize { get; set; }
        public FormWindowState LoggerWindowState { get; set; }
        public Point LoggerWindowPosition { get; set; }
        //public bool LoggerEnableConsole { get; set; }
        public bool LoggerConsoleTimestamps { get; set; }
        public bool LoggerConsoleDevTimestamps { get; set; }
        public int LoggerRetryCount { get; set; }
        public int LoggerRetryAfterSeconds { get; set; }
        //public Font LoggerConsoleFont { get; set; }
        public int LoggerScriptDelay { get; set; }
        public int LoggerRestartAfterSeconds { get; set; }
        public string LoggerJ2534SettingsFile { get; set; }
        public string JConsoleDevice { get; set; }
        public bool JConsoleTimestamps { get; set; }
        public bool JConsoleDevTimestamps { get; set; }
        public bool JConsole4x { get; set; }
        public bool LoggerConsole4x { get; set; }
        public string LoggerJ2534SettingsFile2 { get; set; }
        public int PasteSpecialMode { get; set; }
        public string PasteSpecialPositiveFormula { get; set; }
        public string PasteSpecialNegativeFormula { get; set; }
        public string PasteSpecialTarget { get; set; }
        public string LoggerGraphicsLiveLastProfileFile { get; set; }
        public string LoggerGraphicsLogLastProfileFile { get; set; }
        public int LoggerGraphicsInterval { get; set; }
        public int LoggerGraphicsShowMaxTime { get; set; }
        public bool LoggerGraphicsShowPoints { get; set; }
        public string LoggerGrapohicsBackColor { get; set; }
        public int LoggerGraphicsLineWidth { get; set; }
        public System.Windows.Forms.DataVisualization.Charting.ChartColorPalette LoggerGraphicsColorPalette { get; set; }
        public string LoggerLastLogfile { get; set; }
        public string LoggerTimestampFormat { get; set; }
        public string LoggerLogSeparator { get; set; }
        public string LoggerDecimalSeparator { get; set; }
        public int LoggerGraphicsMouseZoom { get; set; }
        public int LoggerGraphicsMouseWheel { get; set; }
        public int LoggerGraphicsMouseCursor { get; set; }
        public bool TableEditorRememberCompare { get; set; }
        public int TableEditorCompareSelection { get; set; }
        public int TableEditorCompareType { get; set; }
        public bool TunerShowTableCount { get; set; }
        public int NavigatorMaxTablesPerNode { get; set; }
        public int NavigatorMaxTablesTotal { get; set; }
        public bool LoggerStartJ2534Process { get; set; }
        public bool LoggerJ2534ProcessVisible { get; set; }
        public bool LoggerStartJ2534ProcessDebug { get; set; }
        public bool LoggerJ2534ProcessWriteDebugLog { get; set; }
        public bool LoggerAutoDisconnect { get; set; }
        public bool LoggerFilterStartOfMessage { get; set; }
        public bool LoggerFilterTXIndication { get; set; }
        public string LoggerFilterRxStatusCustom { get; set; }
        public string LoggerLastFilterOS { get; set; }
        public ushort LoggerCanPcmAddress { get; set; }
        public string LoggerConnectFlag { get; set; }
        public int LoggerTesterPresentInterval { get; set; }
        public int LoggerConsoleDisplayInterval { get; set; }
        public int LoggerCANWaitSecondsStopMessages { get; set; }
        public int LoggerLoggingMessagesPerRequest { get; set; }

        public int RetryWriteTimes { get; set; }
        public int RetryWriteDelay { get; set; }
        public bool ClearFuncAddrOnDisconnect { get; set; }
        public bool LoggerTestPidCompatibility { get; set; }
        public string LogImportTimeStampFormat { get; set; }
        public bool LogImportTimeStampElapsed { get; set; }
        public bool LoggerGraphDisableResample { get; set; }
        public DataLogger.PidMisMatch LoggerPidMismatch { get; set; }
        public bool LoggerPidMismatchRemember { get; set; }
        public string ControlCommandsFile { get; set; }
        public string MapSessionMapBin { get; set; }
        public string MapSessionRefBin { get; set; }
        public string MapSessionRefTableList { get; set; }
        //public string MapSessionSessionName { get; set; }
        public bool MapSessionUseAutoLoadTableList { get; set; }
        public bool ConfirmProgramExit { get; set; }
        public List<string> HistogramLastLogfileProfiles { get; set; }
        public List<string> HistogramLastLiveProfiles { get; set; }
        public string LastScriptFile { get; set; }
        public string LastJScriptFile { get; set; }
        public int DashboardRows { get; set; }
        public int DashboardCols { get; set; }
        public string TunerColumnsTourist { get; set; }
        public string TunerColumnsBasic { get; set; }
        public string TunerColumnsAdvanced { get; set; }
        public bool TunerAutoresizeColumns { get; set; }
        public bool TunerAutoSaveColumns { get; set; }
        public bool TunerHexWindowShow { get; set; }
        public bool TunerHexWindowHeaders { get; set; }
        public bool TunerHexWindowOffsets { get; set; }
        public bool TunerHexWindowAscii { get; set; }
        public bool TunerHexWindowHighlightBackground { get; set; }
        public int TunerHexWindowWidth { get; set; }
        public int TunerHexWindowColumns { get; set; }
        public string TunerHexWindowBackColor { get; set; }
        public string TunerHexWindowDataColor { get; set; }
        public string TunerHexWindowOtherDataColor { get; set; }
        public string TunerHexWindowSelectionColor { get; set; }
        public string TunerHexWindowModifiedColor { get; set; }
        public bool TunerEnableExtraOffsetButtons { get; set; }
        public bool TunerTreeUseMouseHover { get; set; }
        public bool TableCellMouseHover { get; set; }
        public Upatcher.ConditionalColors TunerColorsMode { get; set; }
        public string TunerColorsMin { get; set; }
        public string TunerColorsMid1 { get; set; }
        public string TunerColorsMid2 { get; set; }
        public string TunerColorsMax { get; set; }
        public Size DashboardWindowSize { get; set; }
        public FormWindowState DashboardWindowState { get; set; }
        public Point DashboardWindowLocation { get; set; }
        public string DashboardLastFile { get; set; }
        public Keys LoggerStartKey { get; set; }
        public int AnalyzerNumMessages { get; set; }
        public int SerialServerPort { get; set; }
        public string SerialServerDevice{ get; set; }
        public string SerialServerFtdiDevice { get; set; }
        public DataLogger.iPortType SerialServerDevicePortType { get; set; }
        public int SerialServerBaudRate { get; set; }
        public string LastLogConverterXml { get; set; }
        public TimeoutScenario TimeoutLoggingActive { get; set; }
        public TimeoutScenario TimeoutLoggingActiveObdlink { get; set; }
        public TimeoutScenario TimeoutLoggingPassive { get; set; }
        public int TimeoutScriptRead { get; set; }
        public int TimeoutSerialPortRead { get; set; }
        public int TimeoutAvtRead { get; set; }
        public int TimeoutSerialPortWrite { get; set; }
        public int TimeoutJ2534Write { get; set; }
        public int TimeoutAnalyzerReceive { get; set; }
        public int TimeoutReceive { get; set; }
        public int TimeoutReceivePerMessage { get; set; }
        public int TimeoutLoggingReceive { get; set; }
        //public int TimeoutScriptWrite { get; set; }
        public int TimeoutConsoleReceive { get; set; }
        public int TimeoutJConsoleReceive { get; set; }

        public WideBand.WBType Wbtype { get; set; }
        public string WBSerial { get; set; }
        public string WBCanID { get; set; }
        public ushort WBCanBytePosition { get; set; }
        public ushort WBCanByteCount { get; set; }
        public double WBCanAfrFactor { get; set; }
        public int WBCanBaudrate { get; set; }
        public bool WBDebug { get; set; }
        public bool WBSkipLeadingZero { get; set; }
        public int UpxLastBaudrate { get; set; }
        public bool IsoTpDebug { get; set; }

        public string TunerTheme { get; set; }
        //public int TimeoutLoggingWrite { get; set; }
        //public int TimeoutJLoggingWrite { get; set; }
        //public int TimeoutJconsoleWrite { get; set; }
        //public int TimeoutJ2534DeviceRead { get; set; }

        public SerializableFont TableEditorFont { get; set; }
        public SerializableFont TableExplorerFont { get; set; }
        public SerializableFont PatcherLogFont { get; set; }
        public SerializableFont DebugFont { get; set; }
        public SerializableFont LoggerConsoleFont { get; set; }
        public SerializableFont TunerHexWindowFont { get; set; }

        public void Save()
        {
            string xmlfile = Path.Combine(Application.StartupPath, "universalpatcher.xml");
            using (FileStream stream = new FileStream(xmlfile, FileMode.Create))
            {
                System.Xml.Serialization.XmlSerializer writer = new System.Xml.Serialization.XmlSerializer(typeof(UpatcherSettings));
                writer.Serialize(stream, this);
                stream.Close();
            }
        }
        public UpatcherSettings ShallowCopy()
        {
            return (UpatcherSettings)this.MemberwiseClone();
        }

    }
    /// <summary>
    /// Font descriptor, that can be xml-serialized
    /// </summary>
    public class SerializableFont
    {
        public string FontFamily { get; set; }
        public GraphicsUnit GraphicsUnit { get; set; }
        public float Size { get; set; }
        public FontStyle Style { get; set; }

        /// <summary>
        /// Intended for xml serialization purposes only
        /// </summary>
        private SerializableFont() { }

        public SerializableFont(Font f)
        {
            FontFamily = f.FontFamily.Name;
            GraphicsUnit = f.Unit;
            Size = f.Size;
            Style = f.Style;
        }

        public SerializableFont(string f)
        {
            string[] parts = f.Split(';');
            if (parts.Length == 3)
            {
                FontFamily = parts[0];
                if (float.TryParse(parts[1], out float s))
                    Size = s;
                if (Enum.TryParse<FontStyle>(parts[2], out FontStyle fs))
                    Style = fs;
                GraphicsUnit = GraphicsUnit.Point;
                //if (Enum.TryParse<GraphicsUnit>(parts[3], out GraphicsUnit gu))
                  //  GraphicsUnit = gu;
            }
        }

        public static SerializableFont FromFont(Font f)
        {
            return new SerializableFont(f);
        }

        public Font ToFont()
        {
            if (string.IsNullOrEmpty(FontFamily))
            {
                return new Font("Consolas", 8);
            }
            return new Font(FontFamily, Size, Style, GraphicsUnit);
        }

        public override string ToString()
        {
            StringBuilder sb = new StringBuilder(FontFamily);
            sb.Append(";" + Size.ToString());
            sb.Append(";" + Style.ToString());
            //sb.Append(";" + GraphicsUnit.ToString());
            return sb.ToString();
        }

    }
    
}
